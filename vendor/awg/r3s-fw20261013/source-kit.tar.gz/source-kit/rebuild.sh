#!/bin/bash
# Rebuild only for the confirmed FriendlyWrt image; do not install on the build host.
set -euo pipefail
cd "$(dirname "$0")"
source_root=$PWD
mkdir -p build/kernel
if [ ! -s build/kernel/Makefile ]; then
    curl -fL --retry 2 -o build/kernel.tar.gz https://codeload.github.com/friendlyarm/kernel-rockchip/tar.gz/30d3e1c2470a7282f37b96fdd4354314dda69aa3
    echo 'bcb6213595c5c6d701105f63b1a4a0da8cb921f05ea382591f2ca6fbe65b9654  build/kernel.tar.gz' | sha256sum -c -
    tar -xzf build/kernel.tar.gz -C build/kernel --strip-components=1
fi
[ "$(make -s -C build/kernel kernelversion)" = 6.1.141 ]
cp firmware.config build/kernel/.config
make -C build/kernel ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- olddefconfig
make -C build/kernel -j4 ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- modules_prepare
cp Module.symvers build/kernel/Module.symvers
make -C awg/src -j4 ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- \
    KERNELDIR="$source_root/build/kernel" WIREGUARD_VERSION=3.1.20260906 module
aarch64-linux-gnu-strip --strip-debug awg/src/amneziawg.ko
cp awg/src/amneziawg.ko ./amneziawg.ko
python3 - <<'PY'
from pathlib import Path
import subprocess
expected = {x.split()[1]: x.split()[0] for x in Path('Module.symvers').read_text().splitlines()}
actual = subprocess.check_output(['modprobe', '--dump-modversions', './amneziawg.ko'], text=True)
for row in actual.splitlines():
    crc, name = row.split()
    assert expected.get(name) == crc, name
assert subprocess.check_output(['modinfo', '-F', 'vermagic', './amneziawg.ko'], text=True).strip() == '6.1.141 SMP mod_unload modversions aarch64'
assert subprocess.check_output(['modinfo', '-F', 'version', './amneziawg.ko'], text=True).strip() == '3.1.20260906'
print('Binary version, vermagic and imported symbol CRC checks passed.')
PY
sha256sum ./amneziawg.ko
